const { app, BrowserWindow, protocol, net, ipcMain, session, shell, Menu, screen, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const http = require('http');
const crypto = require('crypto');
const os = require('os');

protocol.registerSchemesAsPrivileged([{ scheme: 'capmap', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);

const WEB = path.join(__dirname, 'web');
// the app's own folder (an update on the Mac lives in the user folder and leaves out the big speech models)
const BASE = process.env.CAPMAP_BASE_DIR || __dirname, WEB_BASE = path.join(BASE, 'web');
const FFMPEG = process.env.CAPMAP_FFMPEG || path.join(process.resourcesPath || __dirname, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
let CONV;

if (!app.requestSingleInstanceLock()) { app.quit(); }

function inside(root, rel) {
  const p = path.normalize(path.join(root, decodeURIComponent(rel)));
  return p.startsWith(root) ? p : null;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#111214', title: 'CapMap', autoHideMenuBar: true, show: false,
    icon: path.join(WEB, 'icons', 'favicon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false, spellcheck: false }
  });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.loadURL('capmap://app/index.html');
  return win;
}

app.on('second-instance', () => {
  const w = BrowserWindow.getAllWindows()[0];
  if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
});

app.whenReady().then(() => {
  // macOS needs a small app menu, otherwise Cmd+C/V/Q and the like do not work
  Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([{ role: 'appMenu', label: 'CapMap' }, { role: 'editMenu', label: 'Bearbeiten' }, { role: 'windowMenu', label: 'Fenster' }]) : null);
  CONV = path.join(app.getPath('userData'), 'umgewandelt');
  fs.mkdirSync(CONV, { recursive: true });
  // finished exports are kept a day (for saving and uploading), then removed
  try { for (const f of fs.readdirSync(CONV)) if (/^export-/.test(f)) { const p = path.join(CONV, f); if (Date.now() - fs.statSync(p).mtimeMs > 864e5) fs.unlinkSync(p); } } catch (e) {}

  protocol.handle('capmap', req => {
    const u = new URL(req.url);
    const root = u.host === 'local' ? CONV : WEB;
    let rel = u.pathname.replace(/^\/+/, '') || 'index.html';
    let p = inside(root, rel);
    if (p && !fs.existsSync(p) && root === WEB && WEB_BASE !== WEB) p = inside(WEB_BASE, rel);
    if (!p || !fs.existsSync(p)) return new Response('not found', { status: 404 });
    return net.fetch(pathToFileURL(p).toString(), { headers: req.headers });
  });

  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(['media', 'mediaKeySystem', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen', 'notifications', 'display-capture'].includes(perm)));
  session.defaultSession.setPermissionCheckHandler(() => true);

  const mainWin = createWindow();
  require('./updater').initUpdater(mainWin);
  startBridge();
});

app.on('window-all-closed', () => app.quit());

// exported videos: a real "Save as" dialog (starts in the Videos folder) and "show in folder" for uploading
ipcMain.handle('save-video', async (e, { name, data }) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = String(name || 'Video.mp4').replace(/[\\/:*?"<>|]+/g, '').trim() || 'Video.mp4', ext = path.extname(safe).slice(1) || 'mp4';
  const r = await dialog.showSaveDialog(win, { title: 'Video speichern', defaultPath: path.join(app.getPath('videos'), safe), filters: [{ name: 'Video', extensions: [ext] }] });
  if (r.canceled || !r.filePath) return null;
  await fs.promises.writeFile(r.filePath, Buffer.from(data));
  return r.filePath;
});
// ---------- frame-by-frame export: the page sends the encoded video, the mixed sound as WAV, ffmpeg puts both into one MP4
const EXP = new Map();
ipcMain.handle('exp-begin', () => {
  const id = crypto.randomBytes(6).toString('hex'), dir = CONV;
  const v = path.join(dir, `export-${id}.video.mp4`), a = path.join(dir, `export-${id}.audio.wav`);
  EXP.set(id, { v, a, fv: fs.openSync(v, 'w'), fa: null });
  return id;
});
ipcMain.handle('exp-write', (_e, { id, kind, pos, data }) => {
  const x = EXP.get(id); if (!x) throw new Error('Export unbekannt');
  if (kind === 'a' && x.fa == null) x.fa = fs.openSync(x.a, 'w');
  const fd = kind === 'a' ? x.fa : x.fv, b = Buffer.from(data);
  fs.writeSync(fd, b, 0, b.length, pos); return true;
});
function expClean(x, keepOut) { for (const fd of [x.fv, x.fa]) if (fd != null) { try { fs.closeSync(fd); } catch (e) {} } x.fv = x.fa = null; for (const p of [x.v, x.a]) { try { fs.unlinkSync(p); } catch (e) {} } }
ipcMain.handle('exp-cancel', (_e, id) => { const x = EXP.get(id); if (x) { expClean(x); EXP.delete(id); } return true; });
ipcMain.handle('exp-finish', (e, { id, name, audio }) => new Promise((resolve, reject) => {
  const x = EXP.get(id); if (!x) return reject(new Error('Export unbekannt'));
  for (const k of ['fv', 'fa']) if (x[k] != null) { fs.closeSync(x[k]); x[k] = null; }
  const outName = `export-${id}.mp4`, out = path.join(CONV, outName);
  const done = () => { expClean(x); EXP.delete(id); const st = fs.statSync(out); resolve({ path: out, url: 'capmap://local/' + encodeURIComponent(outName), size: st.size }); };
  if (!audio || !fs.existsSync(x.a)) { fs.renameSync(x.v, out); return done(); }
  if (!fs.existsSync(FFMPEG)) { fs.renameSync(x.v, out); return done(); }
  const p = spawn(FFMPEG, ['-hide_banner', '-y', '-i', x.v, '-i', x.a, '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out], { windowsHide: true });
  let err = ''; p.stderr.on('data', d => { err = (err + d).slice(-4000); });
  p.on('error', er => { try { fs.renameSync(x.v, out); done(); } catch (z) { reject(er); } });
  p.on('close', code => { if (code === 0) done(); else { try { fs.renameSync(x.v, out); done(); } catch (z) { reject(new Error('ffmpeg: ' + err.split('\n').slice(-3).join(' '))); } } });
}));
ipcMain.handle('save-exported', async (e, { src, name }) => {
  const win = BrowserWindow.fromWebContents(e.sender), ext = path.extname(name).slice(1) || 'mp4';
  const r = await dialog.showSaveDialog(win, { title: 'Video speichern', defaultPath: path.join(app.getPath('videos'), name), filters: [{ name: 'Video', extensions: [ext] }] });
  if (r.canceled || !r.filePath) return null;
  await fs.promises.copyFile(src, r.filePath); return r.filePath;
});
ipcMain.handle('copy-exported', async (_e, { src, dir, name }) => {
  let p = path.join(dir, name), n = 2; const ext = path.extname(name), base = name.slice(0, name.length - ext.length);
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${n++})${ext}`);
  await fs.promises.copyFile(src, p); return p;
});
ipcMain.handle('pick-folder', async e => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Ordner für die Videos wählen', defaultPath: app.getPath('videos'), properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
ipcMain.handle('write-video', async (_e, { dir, name, data }) => {
  const safe = String(name || 'Video.mp4').replace(/[\\/:*?"<>|]+/g, '').trim() || 'Video.mp4';
  let p = path.join(dir, safe), n = 2; const ext = path.extname(safe), base = safe.slice(0, safe.length - ext.length);
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${n++})${ext}`);
  await fs.promises.writeFile(p, Buffer.from(data)); return p;
});
ipcMain.handle('open-folder', (_e, p) => shell.openPath(p));
ipcMain.handle('show-in-folder', (_e, p) => { if (p && fs.existsSync(p)) { shell.showItemInFolder(p); return true; } return false; });

/* ---------- Claude connector: a local door for the CapMap connector (capmap-mcp.js) used by the Claude app ----------
   Only this computer can reach it (127.0.0.1) and only with the secret token from ~/.capmap/bridge.json. */
const BRIDGE_DIR = path.join(os.homedir(), '.capmap'), BRIDGE_FILE = path.join(BRIDGE_DIR, 'bridge.json');
const pending = new Map(); let reqSeq = 0;
function askRenderer(msg) {
  return new Promise((resolve, reject) => {
    const w = BrowserWindow.getAllWindows()[0]; if (!w) return reject(new Error('Das CapMap-Fenster ist nicht offen.'));
    const id = ++reqSeq, t = setTimeout(() => { pending.delete(id); reject(new Error('Zeitüberschreitung')); }, 30 * 60 * 1000);
    pending.set(id, v => { clearTimeout(t); resolve(v); });
    w.webContents.send('bridge-req', { id, ...msg });
  });
}
ipcMain.on('bridge-res', (_e, m) => { const f = pending.get(m.id); if (f) { pending.delete(m.id); f(m.error ? { error: m.error } : { result: m.result }); } });
function startBridge() {
  const token = crypto.randomBytes(24).toString('hex');
  const srv = http.createServer((req, res) => {
    if (req.method !== 'POST' || req.headers['x-capmap-token'] !== token) { res.writeHead(403); return res.end(); }
    let body = '';
    req.on('data', d => { body += d; if (body.length > 2e6) req.destroy(); });
    req.on('end', async () => {
      let out;
      lastCall = Date.now();
      try { const m = body ? JSON.parse(body) : {}; out = await askRenderer(req.url === '/tools' ? { op: 'list' } : { op: 'call', name: m.name, input: m.input || {} }); }
      catch (e) { out = { error: String(e && e.message || e) }; }
      res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(out));
    });
  });
  srv.listen(0, '127.0.0.1', () => {
    try { fs.mkdirSync(BRIDGE_DIR, { recursive: true }); fs.writeFileSync(BRIDGE_FILE, JSON.stringify({ port: srv.address().port, token, pid: process.pid })); } catch (e) {}
  });
}
app.on('will-quit', () => { try { const b = JSON.parse(fs.readFileSync(BRIDGE_FILE, 'utf8')); if (b.pid === process.pid) fs.unlinkSync(BRIDGE_FILE); } catch (e) {} });
function claudeConfigDirs() {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dirs = process.platform === 'darwin' ? [path.join(os.homedir(), 'Library', 'Application Support', 'Claude')] : [path.join(appdata, 'Claude')];
  try { const pk = path.join(process.env.LOCALAPPDATA || '', 'Packages'); for (const d of fs.readdirSync(pk)) if (/^(AnthropicPBC\.)?Claude/i.test(d)) dirs.push(path.join(pk, d, 'LocalCache', 'Roaming', 'Claude')); } catch (e) {}
  return dirs;
}
let lastCall = 0;
ipcMain.handle('claude-status', () => {
  let connected = false;
  for (const d of claudeConfigDirs()) { try { const c = JSON.parse(fs.readFileSync(path.join(d, 'claude_desktop_config.json'), 'utf8')); if (c.mcpServers && c.mcpServers.capmap) connected = true; } catch (e) {} }
  return { connected, lastCall };
});
ipcMain.handle('claude-open', () => shell.openExternal('claude://').then(() => true, () => false));


/* ---------- CapMap and the Claude app side by side (Windows): CapMap left, Claude right ---------- */
function moveClaudeWindow(x, y, w, h) {
  return new Promise(resolve => {
    const ps = `Add-Type @'
using System; using System.Runtime.InteropServices;
public class CmW { [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }
'@
$p = Get-Process -Name claude -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if ($p) { [CmW]::ShowWindow($p.MainWindowHandle, 9) | Out-Null; Start-Sleep -Milliseconds 150; [CmW]::SetWindowPos($p.MainWindowHandle, [IntPtr]::Zero, ${x}, ${y}, ${w}, ${h}, 0x0040) | Out-Null; [CmW]::SetForegroundWindow($p.MainWindowHandle) | Out-Null; 'ok' } else { 'none' }`;
    const pr = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true });
    let out = ''; pr.stdout.on('data', d => { out += d; }); pr.on('error', () => resolve(false)); pr.on('close', () => resolve(/ok/.test(out)));
  });
}
ipcMain.handle('claude-dock', async (e, on) => {
  const win = BrowserWindow.fromWebContents(e.sender); if (!win) return { ok: false };
  if (!on) { win.maximize(); return { ok: true }; }
  if (process.platform !== 'win32') return { ok: false, reason: 'nur Windows' };
  const d = screen.getDisplayMatching(win.getBounds()), wa = d.workArea, sf = d.scaleFactor || 1;
  const cw = Math.max(440, Math.round(wa.width * .3)), mw = wa.width - cw;
  if (win.isMaximized()) win.unmaximize();
  win.setBounds({ x: wa.x, y: wa.y, width: mw, height: wa.height });
  const px = r => Math.round(r * sf);
  let ok = await moveClaudeWindow(px(wa.x + mw), px(wa.y), px(cw), px(wa.height));
  if (!ok) {
    // the Claude app is not open yet: start it and wait for its window
    try { await shell.openExternal('claude://'); } catch (x) {}
    for (let i = 0; i < 20 && !ok; i++) { await new Promise(r => setTimeout(r, 1000)); ok = await moveClaudeWindow(px(wa.x + mw), px(wa.y), px(cw), px(wa.height)); }
  }
  return { ok };
});
/* ---------- chat inside CapMap with the user's Claude subscription, through Claude Code (claude -p) ----------
   Claude Code runs headless, only with the CapMap tools (via capmap-mcp.js); answers stream back into the CapMap chat. */
function findClaude() {
  const home = os.homedir(), exe = process.platform === 'win32' ? 'claude.exe' : 'claude';
  const c = [process.env.CAPMAP_CLAUDE, path.join(home, '.local', 'bin', exe)];
  for (const d of (process.env.PATH || '').split(path.delimiter)) if (d) c.push(path.join(d, exe));
  // apps started from the Finder do not get the shell PATH
  if (process.platform === 'darwin') for (const d of ['/opt/homebrew/bin', '/usr/local/bin', path.join(home, '.npm-global', 'bin'), path.join(home, '.claude', 'local'), path.join(home, '.bun', 'bin')]) c.push(path.join(d, 'claude'));
  if (process.platform === 'win32') { c.push(path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', 'claude.exe')); c.push(path.join(process.env.APPDATA || '', 'npm', 'claude.cmd')); for (const d of (process.env.PATH || '').split(path.delimiter)) if (d) c.push(path.join(d, 'claude.cmd')); }
  return c.find(f => f && fs.existsSync(f)) || null;
}
let ccProc = null;
ipcMain.handle('cc-status', () => ({ path: findClaude() }));
ipcMain.handle('cc-stop', () => { if (ccProc) { try { ccProc.kill(); } catch (e) {} } return true; });
ipcMain.handle('cc-login', () => {
  const exe = findClaude();
  if (process.platform === 'darwin') {
    const sh = exe ? `'${exe.replace(/'/g, "'\\''")}'` : 'curl -fsSL https://claude.ai/install.sh | bash && ~/.local/bin/claude';
    const script = `echo "CapMap: Claude Code einrichten. Melde dich im Browser mit deinem Claude-Konto an, danach dieses Fenster schliessen."; ${sh}`;
    spawn('osascript', ['-e', `tell application "Terminal" to do script ${JSON.stringify(script)}`, '-e', 'tell application "Terminal" to activate'], { detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  if (process.platform !== 'win32') return false;
  const cmd = exe ? `& '${exe}'` : `irm https://claude.ai/install.ps1 | iex; & "$env:USERPROFILE\\.local\\bin\\claude.exe"`;
  spawn('cmd.exe', ['/c', 'start', 'powershell', '-NoExit', '-Command', `Write-Host 'CapMap: Claude Code einrichten. Melde dich im Browser mit deinem Claude-Konto an, danach dieses Fenster schliessen.' -ForegroundColor Cyan; ${cmd}`], { detached: true, stdio: 'ignore', windowsHide: false }).unref();
  return true;
});
ipcMain.handle('cc-ask', (e, { prompt, session: sid }) => new Promise(resolve => {
  const exe = findClaude(); if (!exe) return resolve({ error: 'Claude Code ist nicht installiert.' });
  const dir = path.join(app.getPath('userData'), 'claude-chat'); fs.mkdirSync(dir, { recursive: true });
  const cfg = path.join(dir, 'capmap-mcp.json');
  fs.writeFileSync(cfg, JSON.stringify({ mcpServers: { capmap: { command: process.execPath, args: [path.join(BASE, 'capmap-mcp.js')], env: { ELECTRON_RUN_AS_NODE: '1' } } } }));
  const q = a => (exe.endsWith('.cmd') && /[\s&()]/.test(a) ? `"${a}"` : a);
  const args = ['-p', '--output-format', 'stream-json', '--verbose', '--mcp-config', q(cfg), '--strict-mcp-config', '--allowedTools', 'mcp__capmap', ...(sid ? ['--resume', sid] : []),
    '--disallowedTools', 'Bash', 'PowerShell', 'Edit', 'Write', 'MultiEdit', 'Read', 'Glob', 'Grep', 'WebFetch', 'WebSearch', 'Task', 'NotebookEdit', 'TodoWrite', 'Monitor'];
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE;
  let p;
  try { p = spawn(exe, args, { cwd: dir, env, windowsHide: true, shell: exe.endsWith('.cmd') }); } catch (err) { return resolve({ error: String(err.message || err) }); }
  ccProc = p;
  let buf = '', errTxt = '', session = sid || null, result = null;
  p.stdout.setEncoding('utf8');
  p.stdout.on('data', d => {
    buf += d; let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
      let m; try { m = JSON.parse(line); } catch (x) { continue; }
      if (m.session_id) session = m.session_id;
      if (m.type === 'result') result = m;
      try { e.sender.send('cc-event', m); } catch (x) {}
    }
  });
  p.stderr.on('data', d => { errTxt = (errTxt + d).slice(-4000); });
  p.on('error', err => { ccProc = null; resolve({ error: String(err.message || err) }); });
  p.on('close', code => { ccProc = null; resolve({ session, code, result, stderr: errTxt }); });
  p.stdin.end(prompt);
}));
/* one click: enter the connector into the Claude app's settings (claude_desktop_config.json), with a backup */
ipcMain.handle('claude-connect', () => {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dirs = process.platform === 'darwin' ? [path.join(os.homedir(), 'Library', 'Application Support', 'Claude')] : [path.join(appdata, 'Claude')];
  try { const pk = path.join(process.env.LOCALAPPDATA || '', 'Packages'); for (const d of fs.readdirSync(pk)) if (/^(AnthropicPBC\.)?Claude/i.test(d)) dirs.push(path.join(pk, d, 'LocalCache', 'Roaming', 'Claude')); } catch (e) {}
  const entry = { command: process.execPath, args: [path.join(BASE, 'capmap-mcp.js')], env: { ELECTRON_RUN_AS_NODE: '1' } };
  const written = [];
  dirs.forEach((d, i) => {
    if (i > 0 && !fs.existsSync(d)) return;
    fs.mkdirSync(d, { recursive: true });
    const f = path.join(d, 'claude_desktop_config.json');
    let cfg = {};
    if (fs.existsSync(f)) {
      const raw = fs.readFileSync(f, 'utf8');
      try { cfg = raw.trim() ? JSON.parse(raw) : {}; } catch (e) { throw new Error('Die Einstellungsdatei der Claude-App ist nicht lesbar: ' + f); }
      fs.writeFileSync(f + '.vor-capmap.json', raw);
    }
    cfg.mcpServers = cfg.mcpServers || {}; cfg.mcpServers.capmap = entry;
    fs.writeFileSync(f, JSON.stringify(cfg, null, 2)); written.push(f);
  });
  return { written, entry };
});

/* ---------- ffmpeg conversion for files the player cannot decode ---------- */
function probeDuration(stderr) {
  const m = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(stderr);
  return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : 0;
}
ipcMain.handle('convert', (e, { id, path: src, type, name }) => new Promise((resolve, reject) => {
  if (!src || !fs.existsSync(src)) return reject(new Error('Datei nicht gefunden'));
  if (!fs.existsSync(FFMPEG)) return reject(new Error('ffmpeg fehlt'));
  const base = path.basename(name || src).replace(/\.[^.]+$/, '');
  const st = fs.statSync(src);
  const key = base.replace(/[^\w\-]+/g, '_').slice(0, 60) + '_' + st.size + '_' + Math.round(st.mtimeMs);
  const spec = type === 'audio' ? { ext: 'mp3', mime: 'audio/mpeg', args: ['-vn', '-c:a', 'libmp3lame', '-b:a', '256k'] }
    : type === 'image' ? { ext: 'png', mime: 'image/png', args: ['-frames:v', '1'] }
    : { ext: 'mp4', mime: 'video/mp4', args: ['-map', '0:v:0', '-map', '0:a:0?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-movflags', '+faststart'] };
  const outName = key + '.' + spec.ext;
  const out = path.join(CONV, outName);
  const done = () => resolve({ url: 'capmap://local/' + encodeURIComponent(outName), name: base + '.' + spec.ext, mime: spec.mime });
  if (fs.existsSync(out) && fs.statSync(out).size > 0) return done();
  const tmp = out + '.part.' + spec.ext;
  const p = spawn(FFMPEG, ['-hide_banner', '-y', '-i', src, ...spec.args, tmp], { windowsHide: true });
  let err = '', dur = 0;
  p.stderr.on('data', d => {
    const s = d.toString(); err = (err + s).slice(-8000);
    if (!dur) dur = probeDuration(err);
    const m = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(s);
    if (m && dur) e.sender.send('convert-progress', { id, p: Math.min(1, ((+m[1]) * 3600 + (+m[2]) * 60 + (+m[3])) / dur) });
  });
  p.on('error', reject);
  p.on('close', code => {
    if (code === 0) { try { fs.renameSync(tmp, out); } catch (x) { return reject(x); } e.sender.send('convert-progress', { id, p: 1 }); done(); }
    else { try { fs.unlinkSync(tmp); } catch (x) {} reject(new Error('ffmpeg: ' + err.split('\n').slice(-4).join(' '))); }
  });
}));
