// Speech recognition with whisper.cpp on the graphics card (Vulkan on Windows, Metal on the Mac).
// Runs as its own process: the native library keeps one model loaded, so a different model means a fresh process,
// and a crash in a graphics driver cannot take CapMap down.
const path = require('path');
let whisper = null, loadErr = '';
try {
  const dir = path.join(__dirname, 'native', 'whisper', process.platform + '-' + process.arch);
  whisper = require(path.join(dir, 'whisper.node')).whisper;
} catch (e) { loadErr = String(e && e.message || e); }

const queue = [];
let busy = false;
function next() {
  if (busy || !queue.length) return;
  busy = true;
  const { id, pcm, language, model } = queue.shift();
  const t0 = Date.now();
  try {
    whisper({
      model, pcmf32: pcm, language: language || 'auto', detect_language: false,
      use_gpu: true, flash_attn: false, translate: false, no_prints: true, no_timestamps: false,
      comma_in_time: false, max_len: 1, audio_ctx: 0
    }, (err, res) => {
      busy = false;
      if (err) process.parentPort.postMessage({ id, error: String(err && err.message || err) });
      else process.parentPort.postMessage({ id, segs: res && res.transcription || [], language: res && res.language || '', ms: Date.now() - t0 });
      next();
    });
  } catch (e) {
    busy = false;
    process.parentPort.postMessage({ id, error: String(e && e.message || e) });
    next();
  }
}
process.parentPort.on('message', e => {
  const m = e.data || {};
  if (m.cmd === 'hello') return process.parentPort.postMessage({ id: m.id, ok: !!whisper, error: loadErr });
  if (m.cmd === 'run') {
    if (!whisper) return process.parentPort.postMessage({ id: m.id, error: loadErr || 'Spracherkennung nicht geladen' });
    queue.push(m); next();
  }
});
