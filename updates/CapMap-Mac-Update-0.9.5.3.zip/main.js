const { app, BrowserWindow, protocol, net, ipcMain, session, shell, Menu, screen, dialog, utilityProcess } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const http = require('http');
const crypto = require('crypto');
const os = require('os');

// H.265 (HEVC) played by the graphics card: on by default since Electron 22, switched on explicitly so nothing turns it off
app.commandLine.appendSwitch('enable-features', 'PlatformHEVCDecoderSupport');
protocol.registerSchemesAsPrivileged([{ scheme: 'capmap', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);

const WEB = path.join(__dirname, 'web');
// the app's own folder (an update on the Mac lives in the user folder and leaves out the big speech models)
const BASE = process.env.CAPMAP_BASE_DIR || __dirname, WEB_BASE = path.join(BASE, 'web');
const FFMPEG = process.env.CAPMAP_FFMPEG || path.join(process.resourcesPath || __dirname, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
let CONV;

// a second start (e.g. by Claude) only wakes the running CapMap and must not touch anything else,
// above all not the bridge file, otherwise Claude would talk to a CapMap that has already quit
if (!app.requestSingleInstanceLock()) { app.exit(0); return; }

function inside(root, rel) {
  const p = path.normalize(path.join(root, decodeURIComponent(rel)));
  return p.startsWith(root) ? p : null;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#111214', title: 'CapMap', autoHideMenuBar: true, show: false,
    icon: path.join(WEB, 'icons', 'favicon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false, spellcheck: false }
  });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.loadURL('capmap://app/index.html');
  return win;
}

app.on('second-instance', () => {
  writeBridge();
  const w = BrowserWindow.getAllWindows()[0];
  if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
});

app.whenReady().then(() => {
  // macOS needs a small app menu, otherwise Cmd+C/V/Q and the like do not work
  Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([{ role: 'appMenu', label: 'CapMap' }, { role: 'editMenu', label: 'Bearbeiten' }, { role: 'windowMenu', label: 'Fenster' }]) : null);
  CONV = path.join(app.getPath('userData'), 'umgewandelt');
  fs.mkdirSync(CONV, { recursive: true });
  // finished exports are kept a day (for saving and uploading), then removed
  try { for (const f of fs.readdirSync(CONV)) if (/^export-/.test(f)) { const p = path.join(CONV, f); if (Date.now() - fs.statSync(p).mtimeMs > 864e5) fs.unlinkSync(p); } } catch (e) {}

  protocol.handle('capmap', req => {
    const u = new URL(req.url);
    // files from a folder the user asked Claude to import (only inside folders listed before)
    if (u.host === 'file') {
      const fp = decodeURIComponent(u.pathname.replace(/^\/+/, ''));
      const ok = fp && [...READ_ROOTS].some(r => { const rel = path.relative(r, fp); return rel && !rel.startsWith('..') && !path.isAbsolute(rel); });
      if (!ok || !fs.existsSync(fp)) return new Response('not found', { status: 404 });
      return serveFile(fp, req);
    }
    const root = u.host === 'local' ? CONV : WEB;
    let rel = u.pathname.replace(/^\/+/, '') || 'index.html';
    let p = inside(root, rel);
    if (p && !fs.existsSync(p) && root === WEB && WEB_BASE !== WEB) p = inside(WEB_BASE, rel);
    if (!p || !fs.existsSync(p)) return new Response('not found', { status: 404 });
    if (root !== WEB) return serveFile(p, req);
    // cross-origin isolation: lets the cut-out and speech models use several processor cores
    return net.fetch(pathToFileURL(p).toString(), { headers: req.headers }).then(r => {
      const h = new Headers(r.headers); h.set('Cross-Origin-Opener-Policy', 'same-origin'); h.set('Cross-Origin-Embedder-Policy', 'credentialless');
      return new Response(r.body, { status: r.status, statusText: r.statusText, headers: h });
    });
  });

  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(['media', 'mediaKeySystem', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen', 'notifications', 'display-capture'].includes(perm)));
  session.defaultSession.setPermissionCheckHandler(() => true);

  const mainWin = createWindow();
  require('./updater').initUpdater(mainWin);
  startBridge();
});

app.on('window-all-closed', () => app.quit());

// exported videos: a real "Save as" dialog (starts in the Videos folder) and "show in folder" for uploading
ipcMain.handle('save-video', async (e, { name, data }) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const safe = String(name || 'Video.mp4').replace(/[\\/:*?"<>|]+/g, '').trim() || 'Video.mp4', ext = path.extname(safe).slice(1) || 'mp4';
  const r = await dialog.showSaveDialog(win, { title: 'Video speichern', defaultPath: path.join(app.getPath('videos'), safe), filters: [{ name: 'Video', extensions: [ext] }] });
  if (r.canceled || !r.filePath) return null;
  await fs.promises.writeFile(r.filePath, Buffer.from(data));
  return r.filePath;
});
// ---------- frame-by-frame export: the page sends the encoded video, the mixed sound as WAV, ffmpeg puts both into one MP4
const EXP = new Map();
ipcMain.handle('exp-begin', () => {
  const id = crypto.randomBytes(6).toString('hex'), dir = CONV;
  const v = path.join(dir, `export-${id}.video.mp4`), a = path.join(dir, `export-${id}.audio.wav`);
  EXP.set(id, { v, a, fv: fs.openSync(v, 'w'), fa: null });
  return id;
});
ipcMain.handle('exp-write', (_e, { id, kind, pos, data }) => {
  const x = EXP.get(id); if (!x) throw new Error('Export unbekannt');
  if (kind === 'a' && x.fa == null) x.fa = fs.openSync(x.a, 'w');
  const fd = kind === 'a' ? x.fa : x.fv, b = Buffer.from(data);
  fs.writeSync(fd, b, 0, b.length, pos); return true;
});
function expClean(x, keepOut) { for (const fd of [x.fv, x.fa]) if (fd != null) { try { fs.closeSync(fd); } catch (e) {} } x.fv = x.fa = null; for (const p of [x.v, x.a]) { try { fs.unlinkSync(p); } catch (e) {} } }
ipcMain.handle('exp-cancel', (_e, id) => { const x = EXP.get(id); if (x) { expClean(x); EXP.delete(id); } return true; });
ipcMain.handle('exp-finish', (e, { id, name, audio }) => new Promise((resolve, reject) => {
  const x = EXP.get(id); if (!x) return reject(new Error('Export unbekannt'));
  for (const k of ['fv', 'fa']) if (x[k] != null) { fs.closeSync(x[k]); x[k] = null; }
  const outName = `export-${id}.mp4`, out = path.join(CONV, outName);
  const done = () => { expClean(x); EXP.delete(id); const st = fs.statSync(out); resolve({ path: out, url: 'capmap://local/' + encodeURIComponent(outName), size: st.size }); };
  if (!audio || !fs.existsSync(x.a)) { fs.renameSync(x.v, out); return done(); }
  if (!fs.existsSync(FFMPEG)) { fs.renameSync(x.v, out); return done(); }
  const p = spawn(FFMPEG, ['-hide_banner', '-y', '-i', x.v, '-i', x.a, '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out], { windowsHide: true });
  let err = ''; p.stderr.on('data', d => { err = (err + d).slice(-4000); });
  p.on('error', er => { try { fs.renameSync(x.v, out); done(); } catch (z) { reject(er); } });
  p.on('close', code => { if (code === 0) done(); else { try { fs.renameSync(x.v, out); done(); } catch (z) { reject(new Error('ffmpeg: ' + err.split('\n').slice(-3).join(' '))); } } });
}));
ipcMain.handle('save-exported', async (e, { src, name }) => {
  const win = BrowserWindow.fromWebContents(e.sender), ext = path.extname(name).slice(1) || 'mp4';
  const r = await dialog.showSaveDialog(win, { title: 'Video speichern', defaultPath: path.join(app.getPath('videos'), name), filters: [{ name: 'Video', extensions: [ext] }] });
  if (r.canceled || !r.filePath) return null;
  await fs.promises.copyFile(src, r.filePath); return r.filePath;
});
ipcMain.handle('copy-exported', async (_e, { src, dir, name }) => {
  let p = path.join(dir, name), n = 2; const ext = path.extname(name), base = name.slice(0, name.length - ext.length);
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${n++})${ext}`);
  await fs.promises.copyFile(src, p); return p;
});
ipcMain.handle('pick-folder', async e => {
  const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Ordner für die Videos wählen', defaultPath: app.getPath('videos'), properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
ipcMain.handle('write-video', async (_e, { dir, name, data }) => {
  const safe = String(name || 'Video.mp4').replace(/[\\/:*?"<>|]+/g, '').trim() || 'Video.mp4';
  let p = path.join(dir, safe), n = 2; const ext = path.extname(safe), base = safe.slice(0, safe.length - ext.length);
  while (fs.existsSync(p)) p = path.join(dir, `${base} (${n++})${ext}`);
  await fs.promises.writeFile(p, Buffer.from(data)); return p;
});
ipcMain.handle('open-folder', (_e, p) => shell.openPath(p));
ipcMain.handle('show-in-folder', (_e, p) => { if (p && fs.existsSync(p)) { shell.showItemInFolder(p); return true; } return false; });

/* ---------- Claude connector: a local door for the CapMap connector (capmap-mcp.js) used by the Claude app ----------
   Only this computer can reach it (127.0.0.1) and only with the secret token from ~/.capmap/bridge.json. */
const BRIDGE_DIR = path.join(os.homedir(), '.capmap'), BRIDGE_FILE = path.join(BRIDGE_DIR, 'bridge.json');
const pending = new Map(); let reqSeq = 0;
function askRenderer(msg) {
  return new Promise((resolve, reject) => {
    const w = BrowserWindow.getAllWindows()[0]; if (!w) return reject(new Error('Das CapMap-Fenster ist nicht offen.'));
    const id = ++reqSeq, t = setTimeout(() => { pending.delete(id); reject(new Error('Zeitüberschreitung')); }, 30 * 60 * 1000);
    pending.set(id, v => { clearTimeout(t); resolve(v); });
    w.webContents.send('bridge-req', { id, ...msg });
  });
}
ipcMain.on('bridge-res', (_e, m) => { const f = pending.get(m.id); if (f) { pending.delete(m.id); f(m.error ? { error: m.error } : { result: m.result }); } });
let BRIDGE_INFO = null;
function writeBridge() { if (!BRIDGE_INFO) return; try { fs.mkdirSync(BRIDGE_DIR, { recursive: true }); fs.writeFileSync(BRIDGE_FILE, JSON.stringify(BRIDGE_INFO)); } catch (e) {} }
function startBridge() {
  const token = crypto.randomBytes(24).toString('hex');
  const srv = http.createServer((req, res) => {
    if (req.method !== 'POST' || req.headers['x-capmap-token'] !== token) { res.writeHead(403); return res.end(); }
    let body = '';
    req.on('data', d => { body += d; if (body.length > 2e6) req.destroy(); });
    req.on('end', async () => {
      let out;
      lastCall = Date.now();
      try { const m = body ? JSON.parse(body) : {}; out = await askRenderer(req.url === '/tools' ? { op: 'list' } : { op: 'call', name: m.name, input: m.input || {} }); }
      catch (e) { out = { error: String(e && e.message || e) }; }
      res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(out));
    });
  });
  srv.listen(0, '127.0.0.1', () => { BRIDGE_INFO = { port: srv.address().port, token, pid: process.pid }; writeBridge(); });
}
app.on('will-quit', () => { try { const b = JSON.parse(fs.readFileSync(BRIDGE_FILE, 'utf8')); if (b.pid === process.pid) fs.unlinkSync(BRIDGE_FILE); } catch (e) {} });
function claudeConfigDirs() {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dirs = process.platform === 'darwin' ? [path.join(os.homedir(), 'Library', 'Application Support', 'Claude')] : [path.join(appdata, 'Claude')];
  try { const pk = path.join(process.env.LOCALAPPDATA || '', 'Packages'); for (const d of fs.readdirSync(pk)) if (/^(AnthropicPBC\.)?Claude/i.test(d)) dirs.push(path.join(pk, d, 'LocalCache', 'Roaming', 'Claude')); } catch (e) {}
  return dirs;
}
let lastCall = 0;
ipcMain.handle('claude-status', () => {
  let connected = false;
  for (const d of claudeConfigDirs()) { try { const c = JSON.parse(fs.readFileSync(path.join(d, 'claude_desktop_config.json'), 'utf8')); if (c.mcpServers && c.mcpServers.capmap) connected = true; } catch (e) {} }
  return { connected, lastCall };
});
ipcMain.handle('claude-open', () => shell.openExternal('claude://').then(() => true, () => false));


/* ---------- CapMap and the Claude app side by side (Windows): CapMap left, Claude right ---------- */
function moveClaudeWindow(x, y, w, h) {
  return new Promise(resolve => {
    const ps = `Add-Type @'
using System; using System.Runtime.InteropServices;
public class CmW { [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }
'@
$p = Get-Process -Name claude -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if ($p) { [CmW]::ShowWindow($p.MainWindowHandle, 9) | Out-Null; Start-Sleep -Milliseconds 150; [CmW]::SetWindowPos($p.MainWindowHandle, [IntPtr]::Zero, ${x}, ${y}, ${w}, ${h}, 0x0040) | Out-Null; [CmW]::SetForegroundWindow($p.MainWindowHandle) | Out-Null; 'ok' } else { 'none' }`;
    const pr = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true });
    let out = ''; pr.stdout.on('data', d => { out += d; }); pr.on('error', () => resolve(false)); pr.on('close', () => resolve(/ok/.test(out)));
  });
}
ipcMain.handle('claude-dock', async (e, on) => {
  const win = BrowserWindow.fromWebContents(e.sender); if (!win) return { ok: false };
  if (!on) { win.maximize(); return { ok: true }; }
  if (process.platform !== 'win32') return { ok: false, reason: 'nur Windows' };
  const d = screen.getDisplayMatching(win.getBounds()), wa = d.workArea, sf = d.scaleFactor || 1;
  const cw = Math.max(440, Math.round(wa.width * .3)), mw = wa.width - cw;
  if (win.isMaximized()) win.unmaximize();
  win.setBounds({ x: wa.x, y: wa.y, width: mw, height: wa.height });
  const px = r => Math.round(r * sf);
  let ok = await moveClaudeWindow(px(wa.x + mw), px(wa.y), px(cw), px(wa.height));
  if (!ok) {
    // the Claude app is not open yet: start it and wait for its window
    try { await shell.openExternal('claude://'); } catch (x) {}
    for (let i = 0; i < 20 && !ok; i++) { await new Promise(r => setTimeout(r, 1000)); ok = await moveClaudeWindow(px(wa.x + mw), px(wa.y), px(cw), px(wa.height)); }
  }
  return { ok };
});
/* ---------- chat inside CapMap with the user's Claude subscription, through Claude Code (claude -p) ----------
   Claude Code runs headless, only with the CapMap tools (via capmap-mcp.js); answers stream back into the CapMap chat. */
function findClaude() {
  const home = os.homedir(), exe = process.platform === 'win32' ? 'claude.exe' : 'claude';
  const c = [process.env.CAPMAP_CLAUDE, path.join(home, '.local', 'bin', exe)];
  for (const d of (process.env.PATH || '').split(path.delimiter)) if (d) c.push(path.join(d, exe));
  // apps started from the Finder do not get the shell PATH
  if (process.platform === 'darwin') for (const d of ['/opt/homebrew/bin', '/usr/local/bin', path.join(home, '.npm-global', 'bin'), path.join(home, '.claude', 'local'), path.join(home, '.bun', 'bin')]) c.push(path.join(d, 'claude'));
  if (process.platform === 'win32') { c.push(path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', 'claude.exe')); c.push(path.join(process.env.APPDATA || '', 'npm', 'claude.cmd')); for (const d of (process.env.PATH || '').split(path.delimiter)) if (d) c.push(path.join(d, 'claude.cmd')); }
  return c.find(f => f && fs.existsSync(f)) || null;
}
let ccProc = null;
ipcMain.handle('cc-status', () => ({ path: findClaude() }));
ipcMain.handle('cc-stop', () => { if (ccProc) { try { ccProc.kill(); } catch (e) {} } return true; });
ipcMain.handle('cc-login', () => {
  const exe = findClaude();
  if (process.platform === 'darwin') {
    const sh = exe ? `'${exe.replace(/'/g, "'\\''")}'` : 'curl -fsSL https://claude.ai/install.sh | bash && ~/.local/bin/claude';
    const script = `echo "CapMap: Claude Code einrichten. Melde dich im Browser mit deinem Claude-Konto an, danach dieses Fenster schliessen."; ${sh}`;
    spawn('osascript', ['-e', `tell application "Terminal" to do script ${JSON.stringify(script)}`, '-e', 'tell application "Terminal" to activate'], { detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  if (process.platform !== 'win32') return false;
  const cmd = exe ? `& '${exe}'` : `irm https://claude.ai/install.ps1 | iex; & "$env:USERPROFILE\\.local\\bin\\claude.exe"`;
  spawn('cmd.exe', ['/c', 'start', 'powershell', '-NoExit', '-Command', `Write-Host 'CapMap: Claude Code einrichten. Melde dich im Browser mit deinem Claude-Konto an, danach dieses Fenster schliessen.' -ForegroundColor Cyan; ${cmd}`], { detached: true, stdio: 'ignore', windowsHide: false }).unref();
  return true;
});
ipcMain.handle('cc-ask', (e, { prompt, session: sid }) => new Promise(resolve => {
  const exe = findClaude(); if (!exe) return resolve({ error: 'Claude Code ist nicht installiert.' });
  const dir = path.join(app.getPath('userData'), 'claude-chat'); fs.mkdirSync(dir, { recursive: true });
  const cfg = path.join(dir, 'capmap-mcp.json');
  fs.writeFileSync(cfg, JSON.stringify({ mcpServers: { capmap: { command: process.execPath, args: [path.join(BASE, 'capmap-mcp.js')], env: { ELECTRON_RUN_AS_NODE: '1' } } } }));
  const q = a => (exe.endsWith('.cmd') && /[\s&()]/.test(a) ? `"${a}"` : a);
  const args = ['-p', '--output-format', 'stream-json', '--verbose', '--mcp-config', q(cfg), '--strict-mcp-config', '--allowedTools', 'mcp__capmap', ...(sid ? ['--resume', sid] : []),
    '--disallowedTools', 'Bash', 'PowerShell', 'Edit', 'Write', 'MultiEdit', 'Read', 'Glob', 'Grep', 'WebFetch', 'WebSearch', 'Task', 'NotebookEdit', 'TodoWrite', 'Monitor'];
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE;
  let p;
  try { p = spawn(exe, args, { cwd: dir, env, windowsHide: true, shell: exe.endsWith('.cmd') }); } catch (err) { return resolve({ error: String(err.message || err) }); }
  ccProc = p;
  let buf = '', errTxt = '', session = sid || null, result = null;
  p.stdout.setEncoding('utf8');
  p.stdout.on('data', d => {
    buf += d; let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
      let m; try { m = JSON.parse(line); } catch (x) { continue; }
      if (m.session_id) session = m.session_id;
      if (m.type === 'result') result = m;
      try { e.sender.send('cc-event', m); } catch (x) {}
    }
  });
  p.stderr.on('data', d => { errTxt = (errTxt + d).slice(-4000); });
  p.on('error', err => { ccProc = null; resolve({ error: String(err.message || err) }); });
  p.on('close', code => { ccProc = null; resolve({ session, code, result, stderr: errTxt }); });
  p.stdin.end(prompt);
}));
/* one click: enter the connector into the Claude app's settings (claude_desktop_config.json), with a backup */
ipcMain.handle('claude-connect', () => {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dirs = process.platform === 'darwin' ? [path.join(os.homedir(), 'Library', 'Application Support', 'Claude')] : [path.join(appdata, 'Claude')];
  try { const pk = path.join(process.env.LOCALAPPDATA || '', 'Packages'); for (const d of fs.readdirSync(pk)) if (/^(AnthropicPBC\.)?Claude/i.test(d)) dirs.push(path.join(pk, d, 'LocalCache', 'Roaming', 'Claude')); } catch (e) {}
  const entry = { command: process.execPath, args: [path.join(BASE, 'capmap-mcp.js')], env: { ELECTRON_RUN_AS_NODE: '1' } };
  const written = [];
  dirs.forEach((d, i) => {
    if (i > 0 && !fs.existsSync(d)) return;
    fs.mkdirSync(d, { recursive: true });
    const f = path.join(d, 'claude_desktop_config.json');
    let cfg = {};
    if (fs.existsSync(f)) {
      const raw = fs.readFileSync(f, 'utf8');
      try { cfg = raw.trim() ? JSON.parse(raw) : {}; } catch (e) { throw new Error('Die Einstellungsdatei der Claude-App ist nicht lesbar: ' + f); }
      fs.writeFileSync(f + '.vor-capmap.json', raw);
    }
    cfg.mcpServers = cfg.mcpServers || {}; cfg.mcpServers.capmap = entry;
    fs.writeFileSync(f, JSON.stringify(cfg, null, 2)); written.push(f);
  });
  return { written, entry };
});

/* ---------- import a whole folder (LUTs, motion graphics, sounds) when Claude is asked to ---------- */
const READ_ROOTS = new Set();
ipcMain.handle('list-folder', (e, { root }) => {
  root = path.resolve(String(root || ''));
  if (!root || !fs.existsSync(root) || !fs.statSync(root).isDirectory()) throw new Error('Ordner nicht gefunden: ' + root);
  const out = [], walk = (dir, depth) => {
    if (depth > 6 || out.length > 3000) return;
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      if (ent.name.startsWith('.') || ent.name === '__MACOSX') continue;
      const fp = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(fp, depth + 1);
      else if (ent.isFile()) out.push({ path: fp, rel: path.relative(path.dirname(root), fp).split(path.sep).join('/'), size: fs.statSync(fp).size });
    }
  };
  walk(root, 0); READ_ROOTS.add(root);
  return out;
});
/* big files (converted videos, sound) straight from disk in large pieces, with ranges for the player;
   net.fetch(file://) through a custom protocol moves them in tiny pieces and is many times slower */
const MIME = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.png': 'image/png', '.json': 'application/json', '.mov': 'video/quicktime', '.gif': 'image/gif', '.cube': 'text/plain', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.flac': 'audio/flac', '.aac': 'audio/aac', '.opus': 'audio/ogg', '.m4v': 'video/mp4', '.mkv': 'video/x-matroska' };
function serveFile(p, req) {
  const { Readable } = require('stream');
  const size = fs.statSync(p).size, type = MIME[path.extname(p).toLowerCase()] || 'application/octet-stream';
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  if (m && size) {
    let a = m[1] === '' ? Math.max(0, size - (+m[2] || 0)) : +m[1], b = m[1] !== '' && m[2] !== '' ? Math.min(+m[2], size - 1) : size - 1;
    if (a > b || a >= size) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    return new Response(Readable.toWeb(fs.createReadStream(p, { start: a, end: b, highWaterMark: 4 << 20 })), { status: 206, headers: { 'Content-Type': type, 'Content-Length': String(b - a + 1), 'Content-Range': `bytes ${a}-${b}/${size}`, 'Accept-Ranges': 'bytes' } });
  }
  return new Response(Readable.toWeb(fs.createReadStream(p, { highWaterMark: 4 << 20 })), { status: 200, headers: { 'Content-Type': type, 'Content-Length': String(size), 'Accept-Ranges': 'bytes' } });
}
/* ---------- ffmpeg conversion for files the player cannot decode ---------- */
function probeDuration(stderr) {
  const m = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(stderr);
  return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : 0;
}
/* graphics-card encoding: NVIDIA (NVENC), Intel (Quick Sync), AMD (AMF) on Windows, VideoToolbox on the Mac.
   Each candidate is tried once with a tiny test encode; the first that works is used, otherwise the processor (libx264). */
const HW_CANDIDATES = process.platform === 'darwin' ? [['h264_videotoolbox', 'Apple-Chip']]
  : process.platform === 'win32' ? [['h264_nvenc', 'NVIDIA'], ['h264_qsv', 'Intel Quick Sync'], ['h264_amf', 'AMD']]
  : [['h264_nvenc', 'NVIDIA'], ['h264_vaapi', 'VA-API']];
const hwFile = () => path.join(app.getPath('userData'), 'umwandeln.json');
const HW = { mode: 'auto', proxy: true, asr: true, enc: null, label: '', probed: false, probing: null };
try { const j = JSON.parse(fs.readFileSync(hwFile(), 'utf8')); if (j.mode === 'off' || j.mode === 'auto') HW.mode = j.mode; if (typeof j.proxy === 'boolean') HW.proxy = j.proxy; if (typeof j.asr === 'boolean') HW.asr = j.asr; } catch (e) {}
function hwSave() { try { fs.writeFileSync(hwFile(), JSON.stringify({ mode: HW.mode, proxy: HW.proxy, asr: HW.asr })); } catch (e) {} }
function hwTry(enc) {
  return new Promise(res => {
    if (enc === 'h264_vaapi') return res(false);
    const args = ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'color=c=black:s=320x240:r=30:d=0.5', ...hwArgs(enc, 2e6), '-f', 'null', '-'];
    let done = false; const fin = ok => { if (!done) { done = true; res(ok); } };
    try { const p = spawn(FFMPEG, args, { windowsHide: true }); p.on('error', () => fin(false)); p.on('close', c => fin(c === 0)); setTimeout(() => { try { p.kill(); } catch (e) {} fin(false); }, 8000); }
    catch (e) { fin(false); }
  });
}
function hwArgs(enc, rate) {
  const br = String(Math.round(rate || 16e6));
  if (enc === 'h264_nvenc') return ['-c:v', 'h264_nvenc', '-preset', 'p4', '-rc', 'vbr', '-cq', '21', '-b:v', '0', '-pix_fmt', 'yuv420p'];
  if (enc === 'h264_qsv') return ['-c:v', 'h264_qsv', '-preset', 'faster', '-global_quality', '22', '-pix_fmt', 'nv12'];
  if (enc === 'h264_amf') return ['-c:v', 'h264_amf', '-quality', 'speed', '-rc', 'cqp', '-qp_i', '20', '-qp_p', '22', '-qp_b', '24', '-pix_fmt', 'yuv420p'];
  if (enc === 'h264_videotoolbox') return ['-c:v', 'h264_videotoolbox', '-b:v', br, '-maxrate', String(Math.round((rate || 16e6) * 1.5)), '-bufsize', String(Math.round((rate || 16e6) * 2)), '-pix_fmt', 'yuv420p'];
  return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p'];
}
function hwProbe() {
  if (HW.probed) return Promise.resolve();
  if (!HW.probing) HW.probing = (async () => {
    if (fs.existsSync(FFMPEG)) for (const [enc, label] of HW_CANDIDATES) if (await hwTry(enc)) { HW.enc = enc; HW.label = label; break; }
    HW.probed = true;
  })();
  return HW.probing;
}
const hwState = () => ({ mode: HW.mode, proxy: HW.proxy, asr: HW.asr, asrOk: asrAvailable(), asrDevice: ASRN.device, enc: HW.enc, label: HW.label, probed: HW.probed });
ipcMain.handle('gpu-status', () => { try { return app.getGPUFeatureStatus(); } catch (e) { return null; } });
ipcMain.handle('hw-get', async () => { await hwProbe(); return hwState(); });
ipcMain.handle('hw-set', async (_e, o) => {
  if (typeof o === 'string') o = { mode: o };
  if (o && o.mode) HW.mode = o.mode === 'off' ? 'off' : 'auto';
  if (o && typeof o.proxy === 'boolean') HW.proxy = o.proxy;
  if (o && typeof o.asr === 'boolean') HW.asr = o.asr;
  hwSave(); await hwProbe(); return hwState();
});
app.whenReady().then(() => setTimeout(() => hwProbe().catch(() => {}), 4000));

/* ---------- speech recognition on the graphics card (whisper.cpp) ---------- */
const ASR_MODELS = {
  tiny: { file: 'ggml-tiny-q8_0.bin', size: 43537433, sha: 'c2085835d3f50733e2ff6e4b41ae8a2b8d8110461e18821b09a15c40c42d1cca' },
  base: { file: 'ggml-base-q8_0.bin', size: 81768585, sha: 'c577b9a86e7e048a0b7eada054f4dd79a56bbfa911fbdacf900ac5b567cbb7d9' },
  // "Sehr genau" on the graphics card: large-v3-turbo (MIT), much more accurate than small and about as fast there
  small: { file: 'ggml-large-v3-turbo-q5_0.bin', size: 574041195, sha: '394221709cd5ad1f40c46e6031ca61bce88931e6e088c188294c6d5a55ffa7e2' },
  // "Deutsch Profi": primeline/whisper-large-v3-turbo-german (Apache-2.0), ggml conversion by cstr (Apache-2.0)
  german: { file: 'ggml-large-v3-turbo-german-q5_0.bin', size: 574041195, sha: '15e92e3db0993c52fffa781513eec9253475331c1be808f8fb409285c9d9d030', url: 'https://huggingface.co/cstr/whisper-large-v3-turbo-german-ggml/resolve/main/ggml-model-q5_0.bin' }
};
const ASR_URL = M => M.url || 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/' + M.file;
const ASR_LANG = { german: 'de', english: 'en', french: 'fr', spanish: 'es', italian: 'it', turkish: 'tr', polish: 'pl', arabic: 'ar' };
const ASRN = { proc: null, model: '', pend: new Map(), seq: 0, device: '', bad: '', dl: new Map() };
const asrNativeDir = () => path.join(__dirname, 'native', 'whisper', process.platform + '-' + process.arch);
const asrAvailable = () => !ASRN.bad && fs.existsSync(path.join(asrNativeDir(), 'whisper.node'));
const asrModelDir = () => process.env.CAPMAP_ASR_MODELS || path.join(app.getPath('userData'), 'spracherkennung');
async function asrModelFile(key, sender) {
  if (process.env.CAPMAP_ASR_TEST_MODEL) return process.env.CAPMAP_ASR_TEST_MODEL;
  const M = ASR_MODELS[key] || ASR_MODELS.base, dir = asrModelDir(), out = path.join(dir, M.file);
  if (fs.existsSync(out) && fs.statSync(out).size === M.size) return out;
  if (ASRN.dl.has(M.file)) return ASRN.dl.get(M.file);
  const job = (async () => {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = out + '.part', res = await net.fetch(ASR_URL(M));
    if (!res.ok || !res.body) throw new Error('Modell-Download: HTTP ' + res.status);
    const hash = crypto.createHash('sha256'), fh = fs.openSync(tmp, 'w'); let got = 0, last = 0;
    try {
      const rd = res.body.getReader();
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        fs.writeSync(fh, value); hash.update(value); got += value.length;
        if (Date.now() - last > 200) { last = Date.now(); try { sender.send('asr-progress', { loaded: got, total: M.size }); } catch (e) {} }
      }
    } finally { fs.closeSync(fh); }
    if (got !== M.size || hash.digest('hex') !== M.sha) { try { fs.unlinkSync(tmp); } catch (e) {} throw new Error('Modell-Download unvollständig'); }
    fs.renameSync(tmp, out); try { sender.send('asr-progress', { loaded: M.size, total: M.size }); } catch (e) {}
    return out;
  })().finally(() => ASRN.dl.delete(M.file));
  ASRN.dl.set(M.file, job);
  return job;
}
function asrProc(model) {
  if (ASRN.proc && ASRN.model === model) return ASRN.proc;
  if (ASRN.proc) { try { ASRN.proc.kill(); } catch (e) {} ASRN.proc = null; }
  // passive waiting: busy-waiting worker threads would fight with the rest of CapMap for the processor
  const env = { ...process.env, OMP_WAIT_POLICY: 'PASSIVE', GOMP_SPINCOUNT: '0' };
  if (process.platform === 'linux') env.LD_LIBRARY_PATH = asrNativeDir() + (env.LD_LIBRARY_PATH ? ':' + env.LD_LIBRARY_PATH : '');
  const p = utilityProcess.fork(path.join(__dirname, 'asr-native.js'), [], { stdio: 'pipe', serviceName: 'CapMap Spracherkennung', env });
  const sniff = d => {
    const s = String(d);
    const v = /ggml_vulkan: \d+ = ([^|(\n]+)/.exec(s), m = /(?:GPU name|found device):\s*([^\n]+)/.exec(s);
    if (v) ASRN.device = v[1].trim(); else if (m && !ASRN.device) ASRN.device = m[1].trim();
  };
  if (p.stderr) p.stderr.on('data', sniff); if (p.stdout) p.stdout.on('data', sniff);
  p.on('message', m => { const r = ASRN.pend.get(m.id); if (r) { ASRN.pend.delete(m.id); m.error ? r.reject(new Error(m.error)) : r.resolve(m); } });
  p.on('exit', code => {
    if (ASRN.proc === p) ASRN.proc = null;
    for (const r of ASRN.pend.values()) r.reject(new Error('Spracherkennung beendet (' + code + ')'));
    ASRN.pend.clear();
  });
  ASRN.proc = p; ASRN.model = model;
  return p;
}
function asrSend(msg, ms = 600000) {
  return new Promise((resolve, reject) => {
    const id = ++ASRN.seq, p = asrProc(msg.model);
    const t = setTimeout(() => { if (ASRN.pend.delete(id)) { reject(new Error('Zeitüberschreitung')); try { p.kill(); } catch (e) {} } }, ms);
    ASRN.pend.set(id, { resolve: v => { clearTimeout(t); resolve(v); }, reject: e => { clearTimeout(t); reject(e); } });
    p.postMessage({ ...msg, id });
  });
}
ipcMain.handle('asr-native', async (e, { pcm, language, model }) => {
  if (!HW.asr) throw new Error('ASR_OFF');
  if (!asrAvailable()) throw new Error(ASRN.bad || 'nicht verfügbar');
  const file = await asrModelFile(model, e.sender);
  if (!ASRN.proc || ASRN.model !== file) {
    const h = await asrSend({ cmd: 'hello', model: file }, 30000);
    if (!h.ok) { ASRN.bad = h.error || 'Laden fehlgeschlagen'; throw new Error(ASRN.bad); }
  }
  const lang = language ? (ASR_LANG[language] || language) : 'auto';
  const r = await asrSend({ cmd: 'run', model: file, pcm, language: lang });
  return { segs: r.segs, ms: r.ms, device: ASRN.device };
});

// what is inside a file: container, video codec and pixel format, audio codec (from ffmpeg's own listing)
function probeMedia(src) {
  return new Promise(res => {
    let err = '';
    try {
      const p = spawn(FFMPEG, ['-hide_banner', '-i', src], { windowsHide: true });
      p.stderr.on('data', d => { err += d.toString(); if (err.length > 200000) err = err.slice(-200000); });
      const done = () => {
        const fmt = (/Input #0, ([^,]+(?:,[^,]+)*?), from/.exec(err) || [])[1] || '';
        const vm = /Stream #0:\d+[^:]*: Video: (\w+)[^,]*,\s*(\w+)/.exec(err), am = /Stream #0:\d+[^:]*: Audio: (\w+)/.exec(err);
        const fm = /Video:[^\n]*?(\d+(?:\.\d+)?) fps/.exec(err) || /Video:[^\n]*?(\d+(?:\.\d+)?) tbr/.exec(err);
        res({ fmt: fmt.trim(), v: vm ? vm[1] : '', pix: vm ? vm[2] : '', a: am ? am[1] : '', fps: fm ? +fm[1] : 0 });
      };
      p.on('close', done); p.on('error', () => res({ fmt: '', v: '', pix: '', a: '' }));
    } catch (x) { res({ fmt: '', v: '', pix: '', a: '' }); }
  });
}
function runFfmpeg(e, id, src, args, out, via, preArgs = []) {
  return new Promise((resolve, reject) => {
    const p = spawn(FFMPEG, ['-hide_banner', '-y', ...preArgs, '-i', src, ...args, out], { windowsHide: true });
    let err = '', dur = 0;
    p.stderr.on('data', d => {
      const s = d.toString(); err = (err + s).slice(-8000);
      if (!dur) dur = probeDuration(err);
      const m = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(s);
      if (m && dur) e.sender.send('convert-progress', { id, via, p: Math.min(1, ((+m[1]) * 3600 + (+m[2]) * 60 + (+m[3])) / dur) });
    });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error('ffmpeg: ' + err.split('\n').slice(-4).join(' '))));
  });
}
/* ---------- smooth slow motion: RIFE (rife-ncnn-vulkan, MIT) computes the frames in between on the graphics card ---------- */
const RIFE_DIR = () => path.join(__dirname, 'native', 'rife');
const rifeBin = () => process.platform === 'win32' ? path.join(RIFE_DIR(), 'win32-x64', 'rife-ncnn-vulkan.exe') : process.platform === 'darwin' ? path.join(RIFE_DIR(), 'darwin', 'rife-ncnn-vulkan') : path.join(RIFE_DIR(), 'linux-x64', 'rife-ncnn-vulkan');
ipcMain.handle('slowmo-ok', () => fs.existsSync(rifeBin()));
const SLOWMO = new Map();
ipcMain.handle('slowmo-cancel', (_e, id) => { const j = SLOWMO.get(id); if (j) { j.cancelled = true; try { j.proc && j.proc.kill(); } catch (x) {} } return true; });
ipcMain.handle('slowmo', async (e, { id, path: src, seg, factor, name }) => {
  if (!src || !fs.existsSync(src)) throw new Error('Datei nicht gefunden');
  const bin = rifeBin(); if (!fs.existsSync(bin)) throw new Error('Zeitlupe ist in dieser Version nicht dabei');
  try { fs.chmodSync(bin, 0o755); } catch (x) {}
  factor = [2, 4, 8].includes(+factor) ? +factor : 4;
  const s0 = Math.max(0, +seg.s || 0), len = Math.max(.1, (+seg.e || 0) - s0);
  const st = fs.statSync(src), base = path.basename(name || src).replace(/\.[^.]+$/, '');
  const key = base.replace(/[^\w\-]+/g, '_').slice(0, 50) + '_' + st.size + '_' + Math.round(st.mtimeMs) + `_slow${factor}_${Math.round(s0 * 1000)}_${Math.round(len * 1000)}`;
  const out = path.join(CONV, key + '.mp4'), result = via => ({ url: 'capmap://local/' + encodeURIComponent(key + '.mp4'), path: out, name: base + ` (Zeitlupe ${factor}x).mp4`, via });
  if (fs.existsSync(out) && fs.statSync(out).size > 0) return result('');
  const job = { cancelled: false, proc: null }; SLOWMO.set(id, job);
  const work = path.join(CONV, 'slowmo-' + crypto.randomBytes(5).toString('hex')), dIn = path.join(work, 'in'), dOut = path.join(work, 'out');
  fs.mkdirSync(dIn, { recursive: true }); fs.mkdirSync(dOut, { recursive: true });
  const send = (p, phase) => { try { e.sender.send('slowmo-progress', { id, p, phase }); } catch (x) {} };
  const run = (cmd, args, onErr) => new Promise((res, rej) => {
    if (job.cancelled) return rej(new Error('cancel'));
    const p = spawn(cmd, args, { windowsHide: true, cwd: work }); job.proc = p; let err = '';
    p.stderr && p.stderr.on('data', d => { err = (err + d).slice(-6000); if (onErr) onErr(String(d)); });
    p.on('error', rej); p.on('close', c => { job.proc = null; job.cancelled ? rej(new Error('cancel')) : c === 0 ? res(err) : rej(new Error(err.split('\n').slice(-4).join(' ') || 'Fehler ' + c)); });
  });
  try {
    const info = await probeMedia(src), fps = info.fps > 1 && info.fps < 241 ? info.fps : 30;
    // 1) the frames of this part, as pictures
    send(0, 'Bilder werden gelesen');
    await run(FFMPEG, ['-hide_banner', '-y', '-ss', String(s0), '-t', String(len), '-i', src, '-map', '0:v:0', '-vsync', '0', '-compression_level', '1', path.join(dIn, '%08d.png')]);
    const n = fs.readdirSync(dIn).length; if (!n) throw new Error('Keine Bilder gelesen');
    const target = n * factor;
    // 2) the frames in between: graphics card first, the processor if there is none
    const watch = setInterval(() => { try { send(.05 + .8 * fs.readdirSync(dOut).length / target, 'Zwischenbilder werden berechnet'); } catch (x) {} }, 400);
    let via = 'Grafikkarte';
    try {
      try { const log = await run(bin, ['-i', dIn, '-o', dOut, '-m', path.join(RIFE_DIR(), 'rife-v4.6'), '-n', String(target), '-f', '%08d.png']); if (/vkCreateInstance failed|invalid gpu|no vulkan|failed to create gpu/i.test(log)) via = 'Prozessor'; }
      catch (x) {
        if (x.message === 'cancel') throw x;
        console.warn('rife gpu', x.message); via = 'Prozessor';
        for (const f of fs.readdirSync(dOut)) fs.unlinkSync(path.join(dOut, f));
        await run(bin, ['-i', dIn, '-o', dOut, '-m', path.join(RIFE_DIR(), 'rife-v4.6'), '-n', String(target), '-g', '-1', '-f', '%08d.png']);
      }
    } finally { clearInterval(watch); }
    // 3) back into a video that plays the new frames at the old speed, so everything moves factor times slower
    send(.87, 'Video wird geschrieben');
    if (HW.mode === 'auto') await hwProbe();
    const tmp = out + '.part.mp4', inArgs = ['-framerate', String(fps), '-i', path.join(dOut, '%08d.png')];
    const enc = HW.mode === 'auto' && HW.enc ? hwArgs(HW.enc, 20e6) : null;
    try { if (!enc) throw new Error('cpu'); await run(FFMPEG, ['-hide_banner', '-y', ...inArgs, ...enc, '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-movflags', '+faststart', tmp]); }
    catch (x) { if (x.message === 'cancel') throw x; await run(FFMPEG, ['-hide_banner', '-y', ...inArgs, '-c:v', 'libx264', '-preset', 'fast', '-crf', '18', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-movflags', '+faststart', tmp]); }
    fs.renameSync(tmp, out); send(1, 'Fertig');
    return result(via);
  } finally {
    SLOWMO.delete(id);
    try { fs.rmSync(work, { recursive: true, force: true }); } catch (x) {}
  }
});
const AUDIO_TAIL = ['-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-movflags', '+faststart'];
const FULL_VF = ['-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2'];
// working copy: the short side becomes 720 px (never larger than the original)
const PROXY_VF = ['-vf', "scale='if(gte(iw,ih),-2,min(720,trunc(iw/2)*2))':'if(gte(iw,ih),min(720,trunc(ih/2)*2),-2)'"];
ipcMain.handle('convert', async (e, { id, path: src, type, name, seg, full, sr }) => {
  if (!src || !fs.existsSync(src)) throw new Error('Datei nicht gefunden');
  if (!fs.existsSync(FFMPEG)) throw new Error('ffmpeg fehlt');
  const base = path.basename(name || src).replace(/\.[^.]+$/, '');
  const st = fs.statSync(src);
  const isSeg = !!(seg && seg.e > seg.s), proxy = type !== 'alpha' && type !== 'pcm16' && type !== 'pcmseg' && type !== 'audio' && type !== 'image' && !isSeg && !full && HW.proxy;
  const rate = Math.round(sr || 48000);
  const key = base.replace(/[^\w\-]+/g, '_').slice(0, 60) + '_' + st.size + '_' + Math.round(st.mtimeMs) + (type === 'alpha' ? '_a' : type === 'pcm16' ? '_p' : type === 'pcmseg' ? `_ps${rate}_${Math.round(seg.s * 1000)}_${Math.round(seg.e * 1000)}` : isSeg ? `_s${Math.round(seg.s * 1000)}_${Math.round(seg.e * 1000)}` : proxy ? '_px' : '');
  // motion graphics with transparency (ProRes 4444 and the like) become WebM with an alpha channel
  const spec = type === 'alpha' ? { ext: 'webm', mime: 'video/webm', args: ['-map', '0:v:0', '-c:v', 'libvpx-vp9', '-pix_fmt', 'yuva420p', '-b:v', '0', '-crf', '32', '-row-mt', '1', '-deadline', 'good', '-cpu-used', '4', '-auto-alt-ref', '0', '-vf', "scale='min(1080,iw)':-2", '-an'] }
    : type === 'pcmseg' ? { ext: 'wav', mime: 'audio/wav', args: ['-map', '0:a:0', '-vn', '-ac', '2', '-ar', String(rate), '-c:a', 'pcm_s16le'] }
    : type === 'pcm16' ? { ext: 'wav', mime: 'audio/wav', args: ['-map', '0:a:0', '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le'] }
    : type === 'audio' ? { ext: 'mp3', mime: 'audio/mpeg', args: ['-vn', '-c:a', 'libmp3lame', '-b:a', '256k'] }
    : type === 'image' ? { ext: 'png', mime: 'image/png', args: ['-frames:v', '1'] }
    : { ext: 'mp4', mime: 'video/mp4', video: true };
  const outName = key + '.' + spec.ext;
  const out = path.join(CONV, outName);
  const result = via => ({ url: 'capmap://local/' + encodeURIComponent(outName), name: base + '.' + spec.ext, mime: spec.mime, path: out, via: via || '', proxy, src });
  if (fs.existsSync(out) && fs.statSync(out).size > 0) return result('');
  const tmp = out + '.part.' + spec.ext;
  const finish = via => { fs.renameSync(tmp, out); e.sender.send('convert-progress', { id, via, p: 1 }); return result(via); };
  const pre = isSeg ? ['-ss', String(Math.max(0, seg.s)), '-t', String(seg.e - Math.max(0, seg.s))] : [];
  if (!spec.video) {
    try { await runFfmpeg(e, id, src, spec.args, tmp, '', pre); return finish(''); }
    catch (x) { try { fs.unlinkSync(tmp); } catch (y) {} throw x; }
  }
  // a playable picture in the wrong wrapper (MPEG-TS, MKV, FLV … often named .mp4 by stream recorders): only repack it, takes seconds
  if (!isSeg) {
    const info = await probeMedia(src);
    const vOk = /^(h264|av1|vp9|vp8)$/.test(info.v) && !/(10le|12le|422|444)/.test(info.pix), aOk = !info.a || /^(aac|mp3|opus)$/.test(info.a);
    if (vOk && aOk && !/^mov,mp4/.test(info.fmt)) {
      const rxOut = path.join(CONV, key.replace(/_px$/, '') + '_rx.mp4'), rxName = path.basename(rxOut);
      const rx = { url: 'capmap://local/' + encodeURIComponent(rxName), name: base + '.mp4', mime: 'video/mp4', path: rxOut, via: 'Umpacken', proxy: false, src };
      if (fs.existsSync(rxOut) && fs.statSync(rxOut).size > 0) return rx;
      const rtmp = rxOut + '.part.mp4';
      const bsf = info.a === 'aac' && /mpegts|flv|aac/.test(info.fmt) ? ['-bsf:a', 'aac_adtstoasc'] : [];
      try {
        await runFfmpeg(e, id, src, ['-map', '0:v:0', '-map', '0:a:0?', '-c', 'copy', ...bsf, '-movflags', '+faststart'], rtmp, 'Umpacken', ['-fflags', '+genpts']);
        fs.renameSync(rtmp, rxOut); e.sender.send('convert-progress', { id, via: 'Umpacken', p: 1 }); return rx;
      } catch (x) { console.warn('remux failed, converting', x.message); try { fs.unlinkSync(rtmp); } catch (y) {} }
    }
  }
  // video: graphics card first (decoding and encoding), the processor if that does not work
  if (HW.mode === 'auto') await hwProbe();
  // a segment (for the export) only reads the part it needs; the working copy is small and fast
  const map = isSeg ? ['-map', '0:v:0', '-an'] : ['-map', '0:v:0', '-map', '0:a:0?'];
  const vf = proxy ? PROXY_VF : FULL_VF, tail = isSeg ? ['-movflags', '+faststart'] : AUDIO_TAIL;
  const vrate = proxy ? 5e6 : 16e6;
  if (HW.mode === 'auto' && HW.enc) {
    try { await runFfmpeg(e, id, src, [...map, ...hwArgs(HW.enc, vrate), ...vf, ...tail], tmp, HW.label, ['-hwaccel', 'auto', ...pre]); return finish(HW.label); }
    catch (x) { console.warn('hw convert failed, using the processor', x.message); try { fs.unlinkSync(tmp); } catch (y) {} }
  }
  const cpu = proxy ? ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-pix_fmt', 'yuv420p'] : hwArgs('libx264');
  try { await runFfmpeg(e, id, src, [...map, ...cpu, ...vf, ...tail], tmp, 'Prozessor', pre); return finish('Prozessor'); }
  catch (x) { try { fs.unlinkSync(tmp); } catch (y) {} throw x; }
});
